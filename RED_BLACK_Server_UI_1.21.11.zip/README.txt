RED//BLACK SERVER RESOURCE PACK
Target: Minecraft Java Edition 1.21.11
Resource-pack version: 75.0

Recreates the red/black GUI style from the supplied screenshot:
inventory/container frame, red hotbar, selected slot, hearts, hunger, XP bar,
crosshair, slot highlights and several common container screens.

This is a recreation of the reference image, not the original author's source pack.

SERVER AUTO-DOWNLOAD
1. Upload the ZIP to a publicly reachable HTTPS URL.
2. Calculate the ZIP's SHA-1 hash.
3. Add these lines to server.properties:

resource-pack=https://YOUR-DOMAIN.example/RED_BLACK_Server_UI_1.21.11.zip
resource-pack-sha1=YOUR_SHA1_HERE
require-resource-pack=true

4. Restart the server.

If your server is not Java 1.21.11, do not use this pack unchanged. The exact
Minecraft version matters for resource-pack paths and pack format.
